REMOVING ANYTHING FROM THIS TXT DOCUMENT AUTOMATICALLY QUALIFIES YOU AS A SHITTY PERSON AND A LEECH!

MultiBot Built By: Hyperz#0001 (704094587836301392)


To start / activate the bot, follow these instructions:


- Make sure you have setup everything in the config.json file

- The BOTS FILES are IN your DOCUMENTS folder!

- You have opened the UpdateBot.bat file ONCE AFTER DOWNLOADING THE BOT!

- Open the StartBot.bat file


- Your bot should be online, having trouble? Contact me here: https://discord.gg/d5Wbegw



Known-Bugs:
- On first startup ban & kick commands **may** crash the bot, just restart it and it should fix itself! ( I dont know why this happens, it just does. There are no errors in console, so when I find a fix I will update the bot on my website here: https://hyperz.dev/ )



Credits:
Physical Programming: Hyperz#0001
Helpful Sources: discord.js.org, DiscordJS Discord Server
Special Thanks: LukaGaming#8725 for help with presence & Monbrey#4502 with his MessageEmbed knowledge!