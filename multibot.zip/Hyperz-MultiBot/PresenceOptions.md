    "presname": "You can make this say anything, it is what they are playing / doing / listening to / watching"
    "prestype": "PLAYING, WATCHING, LISTENING, STREAMING, and a few others"
    "presstatus": "idle, dnd, available (online), invisible (offline (works 50% of the time...))"
