# AuthGG-DiscordBot
AuthGG - C# Discord Bot

<h1> Setup & Initialization
  <h3>
   <li> 1. Goto The "Commands.cs" and goto the very top and input all of your AuthGG application information.
   <li> 2. In "Commands.cs" goto line "281" and line "282" and put your own username & password in the fields.
   <li> 3. Thats it! You're done, you can now use the bot how ever you'd like. Thanks for using my template.
  </h3>
</h1>

<h2> Commands / Features
  
  <li> Generate Keys
  <li> Delete Keys
  <li> Redeem Key
  <li> Kick user from private customer discord if they're not a customer
  <li> Blacklist Command (blacklists user)
  <li> Unblacklist Command
  <li> Extend Subscription
  <li> Download (Checks if user is a customer)
  <li> Expiration Command
  <li> Users (Sends user a message of how many users you have in your AuthGG Application)
  <li> Check user data(admin command)(shows their rank, username, hwid, etc)
  <li> Reset Users HWID
  <li> Give a user a permission to generate keys, reset hwid etc.
</h2>

<h3> Conclusion
  <h4> I hope you enjoy using my C# AuthGG Discord bot. If you have any questions just shoot me a message on UC. Thanks, Best Regards -xo1337.
  </h4>
</h3>    

<h2>Images
  <h4>
    https://cdn.discordapp.com/attachments/792966006682157087/805653894616186890/DeleteKey.png
    https://cdn.discordapp.com/attachments/792966006682157087/805653896634171442/ExpiresBlacklist.png
    https://cdn.discordapp.com/attachments/792966006682157087/805653895589658634/Download.png
    https://cdn.discordapp.com/attachments/792966006682157087/805653902158200842/GetData.png
    https://cdn.discordapp.com/attachments/792966006682157087/805653904557080586/MyInfoCommand.png
    https://cdn.discordapp.com/attachments/792966006682157087/805653904166748160/GetHwid.png
    https://cdn.discordapp.com/attachments/792966006682157087/805653944818466816/ResetHwid.png
    https://cdn.discordapp.com/attachments/792966006682157087/805653946219233300/Screenshot_1.png
    https://cdn.discordapp.com/attachments/792966006682157087/805653950106959892/Users.png
  </h4>
  </h2>

