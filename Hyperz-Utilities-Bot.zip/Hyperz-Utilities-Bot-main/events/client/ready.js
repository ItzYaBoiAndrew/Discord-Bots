const fs = require('fs');
const ms = require('ms');

module.exports = (client, Hyperz, config) =>{
  console.log(`\x1b[36m ${String.raw` ________               ________`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |_____________|        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|                               |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|         Hyperz Utility        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|          Hyperz#0001          |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|         _____________         |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|        |             |        |`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`|________|             |________|`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw` `} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw`https://www.hyperz.dev/`} \x1b[0m`);
  console.log(`\x1b[36m ${String.raw` `} \x1b[0m`);

  console.log(`Make sure you have filled out your config.json file!`);

// Here is where you can set the bots status!
let statuses = [
    {activity: { name: `${config["presence_config"].presname1}`, type: `${config["presence_config"].prestype1}` }, status: `${config["presence_config"].presstatus1}` },
    {activity: { name: `${config["presence_config"].presname2}`, type: `${config["presence_config"].prestype2}` }, status: `${config["presence_config"].presstatus2}` },
    {activity: { name: `${config["presence_config"].presname3}`, type: `${config["presence_config"].prestype3}` }, status: `${config["presence_config"].presstatus3}` }
];
// Fucking Hate Intervals
let i = 0;
setInterval(() => {
     let status = statuses[i];
     if(!status){
         status = statuses[0];
         i = 0;
     }
     client.user.setPresence(status);
     i++;
}, config["presence_config"].preschangetimer);

console.log(`${client.user.tag}, By Hyperz#0001 is now READY!`);
}
