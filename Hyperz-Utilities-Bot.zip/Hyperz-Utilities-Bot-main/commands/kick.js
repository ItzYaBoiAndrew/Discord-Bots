module.exports = {
    name: 'kick',
    description: 'Kicks a user.',
    aliases: ['kickout', 'kik'],
    async execute(client, message, args, Hyperz, config){

    const per = config["permissions_config"].basic_utility_perms
    if(message.member.roles.cache.some(h=>per.includes(h.id))){
        let server = message.guild;
        let kickedmember = message.mentions.users.first().id;
        let reason1 = args.join(" ");

        server.member(kickedmember).kick(reason1)

        const kickEmbed = new Hyperz.MessageEmbed()
        .setColor(config["main_config"].colorhex)
        .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, 'https://hyperz.dev/discord')
        .setDescription('I have kicked that member in this server.')
    
        message.channel.send(kickEmbed).then(msg => msg.delete({ timeout: 10000 }));
        message.delete().catch(err => console.log(err));
    }
    },
}