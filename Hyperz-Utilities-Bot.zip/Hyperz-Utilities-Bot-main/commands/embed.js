module.exports = {
    name: 'embed',
    description: 'Sends an embed as the bot.',
    aliases: ['sayem', 'sayembed'],
    async execute(client, message, args, Hyperz, config){
    const per = config["permissions_config"].basic_utility_perms
    if(message.member.roles.cache.some(h=>per.includes(h.id))){
    const sayEmbed = new Hyperz.MessageEmbed()
    .setColor(config["main_config"].colorhex)
    .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, 'https://github.com/itz-hyperz')
    .setDescription(args.join(" "))
    .setTimestamp()
    .setFooter(`${config["main_config"].copyright}`, `${message.guild.iconURL()}`)
    
    message.delete().catch(err => console.log(err));
    message.channel.send(sayEmbed)
    } else message.channel.send(`You don't have permission to use this command.`).then(msg => msg.delete({ timeout: 10000 }));
    }
}

// Credits:
// Physical Programming: Hyperz#0001

