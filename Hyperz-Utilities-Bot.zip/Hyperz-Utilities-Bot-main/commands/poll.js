module.exports = {
    name: 'poll',
    description: 'Creates a yes or no poll in a server..',
    aliases: ['vote', 'newpoll'],
    async execute(client, message, args, Hyperz, config){
    const per = config["permissions_config"].basic_utility_perms
    if(message.member.roles.cache.some(h=>per.includes(h.id))){
            const pollEmbed = new Hyperz.MessageEmbed()
            .setAuthor(`Poll Created By ${message.author.username}`, message.author.avatarURL())
            .setColor(config["main_config"].colorhex)
            .setURL('https://github.com/itz-hyperz')
            .setDescription(`**Question:** ${args.join(" ")}`)
            .setTimestamp()
            .setFooter(`${config["main_config"].copyright}`);
            
            message.delete().catch(err => console.log(err));
            message.channel.send(pollEmbed).then(message => {
            message.react('❌').then(() => message.react('✅'));
        });
    } else message.channel.send(`You don't have permission to use this command.`).then(msg => msg.delete({ timeout: 10000 }));
    }
}