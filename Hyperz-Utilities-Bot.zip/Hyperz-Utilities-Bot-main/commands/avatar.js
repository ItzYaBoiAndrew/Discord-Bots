module.exports = {
    name: 'avatar',
    description: 'Sends the avatar of the demanding user',
    aliases: ['logo', 'pfp'],
    async execute(client, message, args, Hyperz, config){
        const avatarEmbed = new Hyperz.MessageEmbed()
        .setColor(config["main_config"].colorhex)
        .setThumbnail(message.author.displayAvatarURL())
    
        message.channel.send(avatarEmbed).then(msg => msg.delete({ timeout: 10000 }));
        message.delete().catch(err => console.log(err));
    },
}