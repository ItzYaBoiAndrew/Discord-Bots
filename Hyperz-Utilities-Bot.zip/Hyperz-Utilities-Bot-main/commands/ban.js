module.exports = {
    name: 'ban',
    description: 'Bans a user.',
    aliases: ['banish', 'serverbanish'],
    async execute(client, message, args, Hyperz, config){

    const per = config["permissions_config"].basic_utility_perms
    if(message.member.roles.cache.some(h=>per.includes(h.id))){
            let g = message.guild
            let memberbanned = message.mentions.users.first().id;
            let reason2 = args.join(" ");

            console.log(`Banned User From: ${g.name}`)

            g.members.ban(`${memberbanned}`, {
                reason: `${reason2} - Hyperz Utilities`
              }).catch(console.error);
        }
    },
}
