module.exports = {
    name: 'credits',
    description: 'Displays the bots credits.',
    aliases: ['hyperz', 'creator'],
    async execute(client, message, args, Hyperz, config){
        const pingEmbed = new Hyperz.MessageEmbed()
        .setColor(config["main_config"].colorhex)
        .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, 'https://hyperz.dev/discord')
        .setDescription('This bot was created by [Hyperz#0001](https://hyperz.dev/discord)')
        .setFooter(`www.hyperz.dev/github`)
    
        message.channel.send(pingEmbed)
        message.delete().catch(err => console.log(err));
    },
}