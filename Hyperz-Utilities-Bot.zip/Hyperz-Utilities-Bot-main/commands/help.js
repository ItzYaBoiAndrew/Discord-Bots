module.exports = {
    name: 'help',
    description: 'Displays info about the bot.',
    aliases: ['helpmenu', 'helpme'],
    async execute(client, message, args, Hyperz, config){
        const helpEmbed = new Hyperz.MessageEmbed()
        .setColor(config["main_config"].colorhex)
        .setTitle(`${client.user.username} Help Menu:`)
        .setURL('https://github.com/itz-hyperz')
        .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, 'https://hyperz.dev/discord')
        .setThumbnail(message.guild.iconURL())
        .addFields(
	    { name: 'Global Commands:', value: '`gban` - Globally bans a **mentioned** user from all servers the bots in.\n`gunban` - Globally Unbans a **User ID** from all servers the bots in.'},
            { name: 'Main Commands:', value: '`help` - Shows **all** the __available__ commands!\n`ping` - Pings the bot, if successful it will respond with **"Pong!"**\n`website` - Sends a link to the website of the company.\n`socials` - Sends links of the company socials.\n`avatar` - Sends the avatar of the requesting user.\n`claim` - Claims a ticket.\n`unclaim` - Unclaims a ticket.\n`intro` - Introduces the staff member.\n`outro` - Provides a leaving message for the staff member.\n`dice` - Generates a random number.\n`embed` - Echos what you say into an embed.\n`say` - Echos what you say normally.\n`invite` - Sends an invite to this bots main server.\n`pay` - Provides a payment method.\n`poll` - Creates a yes / no poll.\n`purge` - Delete messages in a channel.\n`tos` - Ask a user to agree to your terms of service.'},
        )
        .setTimestamp()
        .setFooter(`${config["main_config"].copyright}`)
    
        message.author.send(helpEmbed)
        message.delete().catch(err => console.log(err));
    }
}
