module.exports = {
    name: 'unclaim',
    description: 'Unclaim a ticket or channel.',
    aliases: ['unclaimchan', 'unclaimchannel'],
    async execute(client, message, args, Hyperz, config){
    const per = config["permissions_config"].basic_utility_perms
    if(message.member.roles.cache.some(h=>per.includes(h.id))){
        const unclaimEmbed = new Hyperz.MessageEmbed()
        .setColor(config["main_config"].colorhex)
        .setDescription(`**${message.author.tag} has unclaimed this ticket.**`)
        .setTimestamp()
        .setFooter(`${config["main_config"].copyright}`, `${message.guild.iconURL()}`)
        
        message.delete().catch(err => console.log(err));
        message.channel.send(unclaimEmbed)
    } else message.channel.send(`You don't have permission to use this command.`).then(msg => msg.delete({ timeout: 10000 }));
    }
}