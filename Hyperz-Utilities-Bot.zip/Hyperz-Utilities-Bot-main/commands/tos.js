module.exports = {
    name: 'tos',
    description: 'Displays a ToS Agreement.',
    aliases: ['terms', 'tosaccept'],
    async execute(client, message, args, Hyperz, config){
    const per = config["permissions_config"].basic_utility_perms
    if(message.member.roles.cache.some(h=>per.includes(h.id))){
    const tosEmbed = new Hyperz.MessageEmbed()
    .setColor(config["main_config"].colorhex)
    .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, 'https://hyperz.dev/discord')
    .setThumbnail(message.guild.iconURL())
    .addFields(
        { name: 'Terms Of Service:', value: `**${config["main_config"].tos_link}**`},
        { name: 'Notice:', value: 'Please type `"I agree"` to accept the ToS and move forward.'},
    )
    .setTimestamp()
    .setFooter(`${config["main_config"].copyright}`)
    
    message.channel.send(tosEmbed)
    } else message.channel.send(`You don't have permission to use this command.`).then(msg => msg.delete({ timeout: 10000 }));
    }
}