module.exports = {
    name: 'pay',
    description: 'Create a new "invoice" for a user to pay.',
    aliases: ['payment', 'invoice'],
    async execute(client, message, args, Hyperz, config){
    const per = config["permissions_config"].basic_utility_perms
    if(message.member.roles.cache.some(h=>per.includes(h.id))){
    const sayEmbed = new Hyperz.MessageEmbed()
    .setColor(config["main_config"].colorhex)
    .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, 'https://github.com/itz-hyperz')
    .setTimestamp()
    .addFields(
        { name: 'Notice:', value: `The amount due today is: **${args.join(" ")}**.`},
        { name: 'Payment:', value: `Please send your payment as Family / Friends\nto this PayPal Account: **__${config["main_config"].paypal_email}__**`},
    )
    .setFooter(`${config["main_config"].copyright}`, `${message.guild.iconURL()}`)

    message.delete().catch(err => console.log(err));
    message.channel.send(sayEmbed)
    } else message.channel.send(`You don't have permission to use this command.`).then(msg => msg.delete({ timeout: 10000 }));
    }
}