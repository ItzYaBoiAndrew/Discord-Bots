module.exports = {
    name: 'invite',
    description: 'Sends an invite to the main server.',
    aliases: ['mainserver', 'serverinvite'],
    async execute(client, message, args, Hyperz, config){
        message.channel.send(config["main_config"].yourserverinvite).then(msg => msg.delete({ timeout: 10000 }));
        message.delete().catch(err => console.log(err));
    }
}