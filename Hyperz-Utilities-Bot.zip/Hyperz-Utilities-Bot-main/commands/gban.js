module.exports = {
    name: 'gban',
    description: 'Globally bans a user you mention.',
    aliases: ['globalban', 'globallyban', 'exterminate'],
    async execute(client, message, args, Hyperz, config){

    const fuckyou = config["permissions_config"].ban_perms_role_ids
    if (message.member.roles.cache.some(h=>fuckyou.includes(h.id))){

        client.guilds.cache.forEach(g => {

            let memberbanned = message.mentions.users.first().id;
            let reason2 = args.join(" ");

            console.log(`Banned User From: ${g.name}`)

            g.members.ban(`${memberbanned}`, {
                reason: `${reason2} - Hyperz Ban DB`
              }).catch(console.error);
        });

        const banEmbed = new Hyperz.MessageEmbed()
        .setColor(config["main_config"].colorhex)
        .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, 'https://hyperz.dev/discord')
        .setDescription(`I have successfully banned that user from all servers I am in.`)
        .setFooter(`Created by Hyperz#0001`)
    
        message.channel.send(banEmbed).then(msg => msg.delete({ timeout: 10000 }));
        message.delete().catch(err => console.log(err))
    } else console.log(`A user attempted to use the "gban" command, but failed due to lack of permissions.`)
    },
}