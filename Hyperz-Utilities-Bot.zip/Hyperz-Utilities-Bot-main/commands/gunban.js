module.exports = {
    name: 'gunban',
    description: 'Globally unbans a user you mention.',
    aliases: ['globalunban', 'globallyunban', 'unexterminate'],
    async execute(client, message, args, Hyperz, config){

    const fuckyou = config["permissions_config"].ban_perms_role_ids
    if (message.member.roles.cache.some(h=>fuckyou.includes(h.id))){
        client.guilds.cache.forEach(g => {

            let memberbannedid = args.join(" ")

            console.log(`Unbanned User From: ${g.name}`)

            g.members.unban(`${memberbannedid}`).catch(console.error);
        });

        const unbanEmbed = new Hyperz.MessageEmbed()
        .setColor(config["main_config"].colorhex)
        .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, 'https://hyperz.dev/discord')
        .setDescription(`I have successfully unbanned that user from all servers I am in.`)
        .setFooter(`Created by Hyperz#0001`)
    
        message.channel.send(unbanEmbed).then(msg => msg.delete({ timeout: 10000 }));
        message.delete().catch(err => console.log(err))
    } else console.log(`A user attempted to use the "gunban" command, but failed due to lack of permissions.`)
    },
}