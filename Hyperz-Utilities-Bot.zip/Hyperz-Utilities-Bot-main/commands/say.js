module.exports = {
    name: 'say',
    description: 'Says something as the bot.',
    aliases: ['echo', 'talk'],
    async execute(client, message, args, Hyperz, config){
    const per = config["permissions_config"].basic_utility_perms
    if(message.member.roles.cache.some(h=>per.includes(h.id))){
    const sayMessage = args.join(" ");
    message.delete().catch(err => console.log(err));
    message.channel.send(sayMessage)
    } else message.channel.send(`You don't have permission to use this command.`).then(msg => msg.delete({ timeout: 10000 }));
    }
}