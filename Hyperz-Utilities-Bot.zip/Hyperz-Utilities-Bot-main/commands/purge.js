module.exports = {
    name: 'purge',
    description: 'Pings the bot.',
    aliases: ['deletemessages', 'clear'],
    async execute(client, message, args, Hyperz, config){
	const per = config["permissions_config"].basic_utility_perms
    if(message.member.roles.cache.some(h=>per.includes(h.id))){
		let dbjqwbek = message.content.split(' ');
		let deleteCount = 0;
		try {
			deleteCount = parseInt(dbjqwbek[1], 10);
		}catch(err) {
			return message.reply('Please provide the number of messages to delete. (max 100)')
		}
        

		if (!deleteCount || deleteCount < 2 || deleteCount > 100)
			return message.reply('Please provide a number between 2 and 100 for the number of messages to delete');

		const fetched = await message.channel.messages.fetch({
			limit: deleteCount,
		});
		message.channel.bulkDelete(fetched)
			.catch(error => message.reply(`Couldn't delete messages because of: ${error}`));
			message.channel.send(`Successfully Deleted Messages.`).then(msg => msg.delete({ timeout: 6000 }));
	} else message.channel.send(`You don't have permission to use this command.`).then(msg => msg.delete({ timeout: 10000 }));
	},
};