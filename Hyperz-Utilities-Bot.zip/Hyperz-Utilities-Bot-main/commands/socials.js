module.exports = {
    name: 'socials',
    description: 'Sends links to the socials of the owners choices.',
    aliases: ['social', 'connections'],
    async execute(client, message, args, Hyperz, config){
        message.channel.send(`${config["main_config"].your_social1}\n${config["main_config"].your_social2}\n${config["main_config"].your_social3}`)
        message.delete().catch(err => console.log(err));
    },
}