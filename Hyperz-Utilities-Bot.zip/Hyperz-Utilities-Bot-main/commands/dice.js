module.exports = {
    name: 'dice',
    description: 'Generates a random number',
    aliases: ['roll', 'randomnumber'],
    async execute(client, message, args, Hyperz, config){
        if (message.content.toLowerCase().includes(`${config["main_config"].prefix}dice`)) {
            var response = [Math.floor(Math.random() * ((100 - 1) + 1) + 1)];
        
           message.channel.send("You got... " + response + "!").then().catch(console.error).then(msg => msg.delete({ timeout: 10000 }));
           message.delete().catch(err => console.log(err));
        }
    }
}