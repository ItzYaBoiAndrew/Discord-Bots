module.exports = {
    name: 'website',
    description: 'Sends a link to the website of the owners.',
    aliases: ['site', 'websiteurl'],
    async execute(client, message, args, Hyperz, config){
        message.channel.send(`${config["main_config"].your_website}`)
        message.delete().catch(err => console.log(err));
    },
}