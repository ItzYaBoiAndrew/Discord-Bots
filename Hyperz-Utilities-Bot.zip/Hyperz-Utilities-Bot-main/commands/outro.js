module.exports = {
    name: 'outro',
    description: 'Outroduces a user.',
    aliases: ['outroduction', 'complete'],
    async execute(client, message, args, Hyperz, config){
    const per = config["permissions_config"].basic_utility_perms
    if(message.member.roles.cache.some(h=>per.includes(h.id))){
    const claimEmbed = new Hyperz.MessageEmbed()
    .setColor(config["main_config"].colorhex)
    .setDescription(`Thank you for choosing __${message.guild.name}__!\nSincerely ~ **${message.author.username}**`)
    .setTimestamp()
    .setFooter(`${config["main_config"].copyright}`, `${message.guild.iconURL()}`)
    
    message.delete().catch(err => console.log(err));
    message.channel.send(claimEmbed)
        } else message.channel.send(`You don't have permission to use this command.`).then(msg => msg.delete({ timeout: 10000 }));
    }
}