# Hyperz-Utilities-Bot
This is a multi-purpose utilities bot built in DiscordJS.

---

### Features:

- Global Banning System
- Payment System
- ToS Agreement System
- Intro & Outro Commands
- Claim & Unclaim Commands
- Poll System
- Purge / Clear Command
- Say & Sayem Command
- Socials Command
- Website Command
- Bot supports multiple servers
- No Database Needed
- Entirely Free

---

### How-to Install:

- Make sure you have downloaded [NodeJS](https://nodejs.org)
- Open the bots folder
- Run the `UpdateBot.bat` file
- Wait for it to close automatically
- Edit the `config.json` file to match your information
- Run the `StartBot.bat` file
- Then you are done!

---

### Credits:

- Programming by [Hyperz](https://hyperz.dev/discord)

---

### Emotional Support:

- [Beefer](http://beeferdev.wtf)
- [FAXES](https://faxes.zone)
- [Nuclear](https://discord.gg/R66hatQq7h)
